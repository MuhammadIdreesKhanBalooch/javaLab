import java.util.*;
public class Q1 
{
	public static void main(String[] args) 
	{
		Scanner read = new Scanner(System.in);
		double[] numArray  = new double[5];
		for( int  i= 0; i <= 4; i++ ) {
			System.out.print("Enter five numbers in array to check for Armstrong numbers : ");
			numArray[i] = read.nextDouble();
		}
		double  remainder, result = 0;
		for( int i = 0; i < 5; i++ ) {
			while( numArray[i] != 0 ) {
				
				remainder = numArray[i] % 10;
                result += Math.pow(remainder, 3);
                numArray[i] /= 10;
			}
			 if(result == numArray[i])
	                System.out.println(numArray[i] + " is an Armstrong number.");
	            else
	                System.out.println(numArray[i] + " is not an Armstrong number.");
		}
		
		
 	}
}
